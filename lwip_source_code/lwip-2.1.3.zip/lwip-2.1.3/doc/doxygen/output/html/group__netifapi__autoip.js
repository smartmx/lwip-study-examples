var group__netifapi__autoip =
[
    [ "netifapi_autoip_start", "group__netifapi__autoip.html#gaca26bae2a21e0732a7599df14f880af2", null ],
    [ "netifapi_autoip_stop", "group__netifapi__autoip.html#gae604f96907a52557e4ebd1bd5d80071d", null ]
];