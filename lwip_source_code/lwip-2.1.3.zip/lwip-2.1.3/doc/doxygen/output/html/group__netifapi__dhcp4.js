var group__netifapi__dhcp4 =
[
    [ "netifapi_dhcp_inform", "group__netifapi__dhcp4.html#ga29108975e9aa6463b9a574de961317e0", null ],
    [ "netifapi_dhcp_release", "group__netifapi__dhcp4.html#ga5aeaee24c11128df90a56fe091c9d409", null ],
    [ "netifapi_dhcp_release_and_stop", "group__netifapi__dhcp4.html#ga1971af04f882f5afdb3ade454a680134", null ],
    [ "netifapi_dhcp_renew", "group__netifapi__dhcp4.html#ga642390e5efa53ad3095e01331c6a936b", null ],
    [ "netifapi_dhcp_start", "group__netifapi__dhcp4.html#gae64d13afc6e3b0f21aae04b66d0e3765", null ],
    [ "netifapi_dhcp_stop", "group__netifapi__dhcp4.html#ga2322c0d0e3eb6c1097d6f3942905dbd5", null ]
];