var group__ieee =
[
    [ "lwip_ieee_eth_type", "group__ieee.html#gab3a7b97666b100584972d158acbbd1f4", [
      [ "ETHTYPE_IP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4ac95756b20fde70b868ef4185dd221c79", null ],
      [ "ETHTYPE_ARP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a41217db03576ea59c44b28b248c39be5", null ],
      [ "ETHTYPE_WOL", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a530a30feb9b87fd993da2bf83776cf9b", null ],
      [ "ETHTYPE_RARP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a14292184cb41b279249319896d0e2b1f", null ],
      [ "ETHTYPE_VLAN", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4ad8f84826d52d92ac24a477d1f03e7903", null ],
      [ "ETHTYPE_IPV6", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4aab26004eed559217be5dd466a79b1383", null ],
      [ "ETHTYPE_PPPOEDISC", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a58c6f40d7cc3edb9455762938f3f6569", null ],
      [ "ETHTYPE_PPPOE", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a8c0e8f68b90134eb4f1f17d3d2eb6f8c", null ],
      [ "ETHTYPE_JUMBO", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a2511e8a31961bd742363b11b274b9dd1", null ],
      [ "ETHTYPE_PROFINET", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a889eb8f716238d16ee3408f16a5cf19d", null ],
      [ "ETHTYPE_ETHERCAT", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a5085a5fd5f9c9506124e93ea43ad2d7c", null ],
      [ "ETHTYPE_LLDP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a02eab0dd87f222a2d555ca38b1b8afcc", null ],
      [ "ETHTYPE_SERCOS", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4ab93419f8edf5692e91629ab92fce8a14", null ],
      [ "ETHTYPE_MRP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4ad36caec44d8db59ff433a8bd3e92ad3e", null ],
      [ "ETHTYPE_PTP", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4aa3e9e834eef932d073028e28eb8793dc", null ],
      [ "ETHTYPE_QINQ", "group__ieee.html#ggab3a7b97666b100584972d158acbbd1f4a39a18006412cbb57536535bd9d378394", null ]
    ] ]
];