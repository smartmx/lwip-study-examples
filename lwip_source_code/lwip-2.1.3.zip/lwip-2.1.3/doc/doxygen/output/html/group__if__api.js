var group__if__api =
[
    [ "lwip_if_indextoname", "group__if__api.html#gac68ad9ef70eb869525e0a1cc818f056b", null ],
    [ "lwip_if_nametoindex", "group__if__api.html#ga76d07962b9d19c3c6f578de780e2c3be", null ]
];