var altcp__tls__mbedtls__opts_8h =
[
    [ "ALTCP_MBEDTLS_DEBUG", "altcp__tls__mbedtls__opts_8h.html#a7727456eeb0b3311213936413d238989", null ],
    [ "ALTCP_MBEDTLS_LIB_DEBUG", "altcp__tls__mbedtls__opts_8h.html#a12262be84ab6a04e2aff7ca152328308", null ],
    [ "ALTCP_MBEDTLS_LIB_DEBUG_LEVEL_MIN", "altcp__tls__mbedtls__opts_8h.html#ad8561bbfabb4ec81ad1c4d7304d16bb5", null ],
    [ "ALTCP_MBEDTLS_SESSION_CACHE_SIZE", "altcp__tls__mbedtls__opts_8h.html#a1c8a3f37f8ede74835b03eedcdc41973", null ],
    [ "ALTCP_MBEDTLS_SESSION_CACHE_TIMEOUT_SECONDS", "altcp__tls__mbedtls__opts_8h.html#a6acb28346f87b2310fc00ec1fccba2b6", null ],
    [ "ALTCP_MBEDTLS_SESSION_TICKET_CIPHER", "altcp__tls__mbedtls__opts_8h.html#a4917dbc00f43f88eb703c8ba89bd37f6", null ],
    [ "ALTCP_MBEDTLS_SESSION_TICKET_TIMEOUT_SECONDS", "altcp__tls__mbedtls__opts_8h.html#a66eff71890153166578b0b78d780ac50", null ],
    [ "ALTCP_MBEDTLS_USE_SESSION_CACHE", "altcp__tls__mbedtls__opts_8h.html#abd6b53a101f046337a4d77c749dbab66", null ],
    [ "ALTCP_MBEDTLS_USE_SESSION_TICKETS", "altcp__tls__mbedtls__opts_8h.html#ae3dbc4de0fc53bcda746c9dfd5618d3b", null ],
    [ "LWIP_ALTCP_TLS_MBEDTLS", "altcp__tls__mbedtls__opts_8h.html#ac8dbfe10a4a9a64c1e2c62ea97e48639", null ]
];