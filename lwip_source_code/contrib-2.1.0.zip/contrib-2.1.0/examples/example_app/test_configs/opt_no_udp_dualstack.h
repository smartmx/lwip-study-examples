#include "test_configs/opt_dualstack.h"

#undef LWIP_UDP
#define LWIP_UDP 0