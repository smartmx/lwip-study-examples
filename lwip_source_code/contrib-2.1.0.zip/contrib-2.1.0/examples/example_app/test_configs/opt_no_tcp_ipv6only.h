#include "test_configs/opt_ipv6only.h"

#undef LWIP_TCP
#define LWIP_TCP 0