#include "test_configs/opt_ipv4only.h"

#undef LWIP_UDP
#define LWIP_UDP 0