﻿namespace Lextm.SharpSnmpLib.Mib.Elements.Types
{
    public interface ITypeAssignment : IDeclaration
    {
    }
}
