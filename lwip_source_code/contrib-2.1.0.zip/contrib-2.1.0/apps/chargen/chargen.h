#ifndef LWIP_CHARGEN_H
#define LWIP_CHARGEN_H

#include "lwip/opt.h"

#if LWIP_SOCKET

void chargen_init(void);

#endif /* LWIP_SOCKET */

#endif /* LWIP_CHARGEN_H */
